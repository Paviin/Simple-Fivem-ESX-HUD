Config = {}

Config.UpdateIntervalSV = 750 -- Every 750ms it gets updated (Server side)
Config.UpdateIntervalCL = 250 -- Every 250ms it gets updated (Client side)

Config.ServerName = '<h1><span style="color: rgb(20, 135, 171);">server</span>name</h1>'
Config.KMH = true  -- Otherwise mph